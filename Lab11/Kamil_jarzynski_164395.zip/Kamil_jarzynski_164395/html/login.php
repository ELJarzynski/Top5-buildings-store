<main>
    <div id="rejestracja">
    <form name="rejestracjaForm" method="post" action="register_finish.php" onsubmit="return validateForm()">
    <table>
        <tr>
            <td>Login: </td><td><input type="text" id="login" name="login" required placeholder="Wpisz login"></td>
        </tr>
        <tr>
            <td>Hasło: </td><td><input type="password" id="passw"  name="password" required placeholder="Wpisz hasło"></td>
        </tr>
    </table>
    </form>
    </div>
</main>