<?php
/**
 * Klasa Cfg zawierająca statyczne pola z danymi konfiguracyjnymi, takimi jak nazwa użytkownika i hasło dla administratora.
 */
class Cfg
{

     // Stałe pole przechowujące nazwę użytkownika.
    public static string $user_name = "kamil";

     // Stałe pole przechowujące hasło użytkownika.
      public static string $user_pass = "limos1";
}
?>